#
#   examon_api.py
#
#   Author: Francesco Beneventi
#
#   16/03/2022
#

import json
import requests
from requests.auth import HTTPBasicAuth
import functools


def api_error_handler(func):
    """
    Decorator to handle API errors consistently across all API functions.
    Catches and formats errors from requests and JSON processing.
    """
    @functools.wraps(func)
    def wrapper(*args, **kwargs):
        try:
            return func(*args, **kwargs)
        except requests.exceptions.ConnectionError:
            return {'message': 'Failed to connect to the server. Please check the server IP and port.'}
        except requests.exceptions.Timeout:
            return {'message': 'Request timed out. Please try again later.'}
        except requests.exceptions.RequestException as e:
            return {'message': f'Request error: {str(e)}'}
        except json.JSONDecodeError as e:
            return {'message': f'Error parsing JSON data: {str(e)}'}
        except (KeyError, IndexError) as e:
            return {'message': f'Error accessing response data: {str(e)}'}
        except Exception as e:
            return {'message': f'Unexpected error: {str(e)}'}
    return wrapper


@api_error_handler
def get_energy_by_job_id(server_ip, port, username, password, job_id):

    # Endpoint
    api_url = f'http://{server_ip}:{port}/api/v1/examon/jobs/query'

    # JSON data to be sent in the request body
    data = {
        "tags": {
            "job_id": [
                job_id
            ]
        },
        "time_zone": "Europe/Rome",
        "aggrby": None,
        "metrics": [
            "job_info_E4red"
        ],
        "limit": None,
        "tstart": 1000,
        "tstop": None,
        "groupby": [
            {
                "name": "tag",
                "tags": [
                    "energy"
                ]
            }
        ]
    }

    headers = {
        'Content-Type': 'application/json',
        'Accept-Encoding': 'gzip, deflate'
    }

    # the payload should be encoded as follow:
    json_data = json.dumps(json.dumps(data)).encode("utf-8")

    # Set up basic authentication
    auth = HTTPBasicAuth(username, password)

    # Send POST request with JSON content and basic authentication
    response = requests.post(api_url, data=json_data, auth=auth, headers=headers)

    # Check the response status code
    if response.status_code == 200:
        ret = json.loads(response.json())
        if len(ret) > 0:
            return json.loads(ret[0]['energy'])
        else:
            return {'message': 'No data found'}
    else:
        return {'message': f'Request failed with status code {response.status_code}. Response content: {response.text}'}
