#!/usr/bin/env python
#
#   examon_cli.py
#
#   Author: Francesco Beneventi
#
#   16/03/2022
#

import json
import click
from prompt_toolkit import PromptSession
from prompt_toolkit.completion import WordCompleter
from prompt_toolkit.history import FileHistory
import shlex
import os
from pathlib import Path

from api.examon_api import get_energy_by_job_id
from examon_cli.version import __version__


config = {
    'username': '',
    'password': '',
    'server_ip': '',
    'port': ''
}

@click.version_option(version=__version__, prog_name='examon-cli')
@click.option('-U', 'username', help='Examon username', required=True)
@click.option('-P', 'password', help='Examon password', required=True)
@click.option('-H', 'server_ip', help='Examon server address', required=True)
@click.option('-p', 'port', help='Examon server port', required=True)
@click.group()
def cli(username, password, server_ip, port):
    """
    ExaMon Command Line Interface
    \f

    Args:
        username (str): The username for Examon.
        password (str): The password for Examon.
        server_ip (str): The server IP address for Examon.
        port (str): The server port for Examon.

    Returns:
        None
    """
    config['username'] = username.strip()
    config['password'] = password.strip()
    config['server_ip'] = server_ip.strip()
    config['port'] = port.strip()
    
    return

@cli.command()
@click.option('--job_id', type=int, help='The id of the job', required=True)
@click.option('--user_id', type=str, help='The user id of the job owner', required=False)
def energy(job_id=None, user_id=None):
    """
    Return the total energy consumption of a job.
    \f

    Args:
        job_id (int): The id of the job.
        user_id (str): The user id of the job owner (optional,  Future feature).

    Example:
        examon-cli.py energy --job_id 123
    """
    if job_id is None and user_id is None:
        click.echo("Either job_id or user_id must be provided")
        return
    elif job_id is not None and user_id is not None:
        click.echo("Not Implemented")
        return
    elif job_id is not None:
        ret = get_energy_by_job_id(config['server_ip'], config['port'], config['username'], config['password'], job_id)
        if ret:
            click.echo(json.dumps(ret, indent=4)) 
        return
    elif user_id is not None:
        click.echo("Not Implemented")
        return
    else:
        click.echo("Invalid arguments")
    


@cli.command()
def shell():
    """
    Start an interactive shell for ExaMon commands.
    \f
    """
    # Get available commands from the cli group
    available_commands = list(cli.commands.keys())
    
    # Create command completer
    command_completer = WordCompleter(available_commands + ['exit', 'help'])
    
    # Create a history file in the user's home directory
    history_file = os.path.join(str(Path.home()), '.examon_history')
    session = PromptSession(
        history=FileHistory(history_file),
        completer=command_completer,
    )

    click.echo("ExaMon Shell. Type 'help' for available commands or 'exit' to quit.")
    
    while True:
        try:
            user_input = session.prompt('examon> ')
            command = user_input.strip()
            
            if not command:
                continue
                
            if command == 'exit':
                break
                
            if command == 'help':
                click.echo("Available commands:")
                for cmd_name in available_commands:
                    cmd = cli.get_command(None, cmd_name)
                    click.echo(f"  {cmd_name}: {cmd.help}")
                click.echo("  exit: Exit the ExaMon shell")
                click.echo("  help: Show this help message")
                continue
                
            # Parse the command line
            try:
                args = shlex.split(command)
                cmd_name = args[0]
                cmd_args = args[1:] if len(args) > 1 else []
                
                if cmd_name in available_commands:
                    # Get the command from the CLI group
                    cmd = cli.get_command(None, cmd_name)
                    
                    # Execute the command
                    ctx = click.Context(cli, info_name=cli.name, parent=None)
                    ctx.ensure_object(dict)
                    ctx.obj = {}
                    cmd.parse_args(ctx, cmd_args)
                    cmd.callback(**ctx.params)
                else:
                    click.echo(f"Unknown command: {cmd_name}")
            except click.exceptions.UsageError as e:
                click.echo(f"Error: {e}")
            except Exception as e:
                click.echo(f"Error executing command: {e}")
        except KeyboardInterrupt:
            click.echo("\nUse 'exit' to quit.")
        except EOFError:
            break

if __name__ == '__main__':
    cli()
