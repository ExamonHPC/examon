from setuptools import setup, find_packages

exec(open('examon_cli/version.py').read())

setup(
    name='examon_cli',
    version=__version__,
    packages=find_packages(),
    include_package_data=True,
    install_requires=[
        'click',
        'prompt_toolkit',
        'requests'
    ],
    entry_points={
        'console_scripts': [
            'examon-cli=examon_cli.examon_cli:cli',
        ]
    }

)